        const products = [
            { name: "D-TIR", price: 100.000 },
            { name: "MP40", price: 35.000 },
            { name: "STG-42", price: 55.000 }
        ];

        const cartItems = [];

        function renderProducts(filteredProducts = products) {
            const productListDiv = document.getElementById('product-list');
            productListDiv.innerHTML = '';

            filteredProducts.forEach(product => {
                const productDiv = document.createElement('div');
                productDiv.className = 'product';
                productDiv.textContent = `${product.name}: $${product.price.toFixed(2)}`;
                const addButton = document.createElement('button');
                addButton.textContent = 'Agregar al Carrito';
                addButton.onclick = () => addToCart(product);
                productDiv.appendChild(addButton);
                productListDiv.appendChild(productDiv);
            });
        }

        function addToCart(product) {
            cartItems.push(product);
            renderCart();
        }

        function renderCart() {
            const cartDiv = document.getElementById('cart');
            cartDiv.innerHTML = '';

            cartItems.forEach((item, index) => {
                const itemDiv = document.createElement('div');
                itemDiv.className = 'cart-item';
                itemDiv.textContent = `${item.name}: $${item.price.toFixed(2)}`;
                const removeButton = document.createElement('button');
                removeButton.textContent = 'Eliminar';
                removeButton.onclick = () => removeFromCart(index);
                itemDiv.appendChild(removeButton);
                cartDiv.appendChild(itemDiv);
            });

            const total = cartItems.reduce((sum, item) => sum + item.price, 0);
            document.getElementById('total').textContent = `Total: $${total.toFixed(2)}`;
        }

        function removeFromCart(index) {
            cartItems.splice(index, 1);
            renderCart();
        }

        function filterProducts() {
            const query = document.getElementById('search').value.toLowerCase();
            const filteredProducts = products.filter(product => product.name.toLowerCase().includes(query));
            renderProducts(filteredProducts);
        }

        window.onload = () => {
            renderProducts();
            renderCart();
        };

        function proceedToCheckout() {
            alert("Procediendo al pago...");
        }
