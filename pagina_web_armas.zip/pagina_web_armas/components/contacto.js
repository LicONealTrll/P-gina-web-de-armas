document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que la página se recargue
    alert('¡Gracias por tu mensaje!');

    // Crear un nuevo elemento dinámico
    const nuevoMensaje = document.createElement('div');
    nuevoMensaje.textContent = 'Tu mensaje ha sido enviado.';
    nuevoMensaje.className = 'mensaje-confirmacion'; // Puedes añadir estilos CSS si lo deseas
    document.body.appendChild(nuevoMensaje);
});

const miImagen = document.getElementById('miImagen');
const miFlecha = document.getElementById('miFlecha');

let contador = 0; // Contador para las imágenes
const imagenes = [
    '../assets/css/img/img1.jpg',
    '../assets/css/img/img2.jpg',
    '../assets/css/img/img3.jpg',
    '../assets/css/img/img4.jpg',
    '../assets/css/img/img5.jpg',
    '../assets/css/img/img6.jpg',
    '../assets/css/img/img7.jpg',
    '../assets/css/img/img8.jpg',
    '../assets/css/img/img9.jpg',
    '../assets/css/img/img10.jpg',
    '../assets/css/img/img11.jpg',
    '../assets/css/img/img12.jpg',
    '../assets/css/img/img13.jpg',
    '../assets/css/img/img14.jpg'
];

miFlecha.addEventListener('click', function() {
    // Cambiamos la fuente de la imagen según el contador
    contador = (contador + 1) % imagenes.length; // Aumenta el contador y vuelve a 0 si supera el índice
    miImagen.src = imagenes[contador]; // Cambia la imagen

    const eventoCambioImagen = new CustomEvent('imagenCambiada', { detail: { contador } });
    document.dispatchEvent(eventoCambioImagen);
});

// Escuchar el evento personalizado
document.addEventListener('imagenCambiada', function(e) {
    console.log('La imagen ha sido cambiada a la número:', e.detail.contador);
});

// Agregar eventos mouseover y mouseout para la imagen
miImagen.addEventListener('mouseover', function() {
    this.style.transform = 'scale(1.1)'; // Aumenta el tamaño
});
miImagen.addEventListener('mouseout', function() {
    this.style.transform = 'scale(1)'; // Vuelve al tamaño original
});
