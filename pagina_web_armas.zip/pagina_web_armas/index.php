<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WONDER WEAPONS</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Fuente Roboto -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <!-- Estilo de index -->
    <link rel="stylesheet" href="assets/css/index.css">
</head>

<body>
    <div class="hero">
        <h1>Bienvenido a la Galería de Armas</h1>
    </div>
    <div class="container mt-5">
        <h2 class="text-center">Explora Nuestras Opciones</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="assets/css/img/wps.jpg" class="card-img-top" alt="Armas">
                    <div class="card-body">
                        <h5 class="card-title">Lista de Armas</h5>
                        <p class="card-text">Accede a una tabla de datos de armas.</p>
                        <a href="pages_php/datatable.php" class="btn btn-primary">Ver Lista</a>
                    </div>
                </div>
            </div>
            <!-- Carrito -->
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="assets/css/img/car.jpg" class="card-img-top" alt="Otra Arma">
                    <div class="card-body">
                        <h5 class="card-title">Carrito</h5>
                        <p class="card-text">Agrega tus armas favoritas al carrito!</p>
                        <a href="pages_php/carrito.php" class="btn btn-primary">Ir al Carrito</a>
                    </div>
                </div>
            </div>
            <!-- Sección de Animaciones -->
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="assets/css/img/dom.jpg" class="card-img-top" alt="Otra Arma">
                    <div class="card-body">
                        <h5 class="card-title">Contacto</h5>
                        <p class="card-text">Dejame saber tu opinion sobre mi pagina web</p>
                        <a href="pages_php/contacto.php" class="btn btn-primary">Ver Más</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3 mt-5">
        <div class="container">
            <p>&copy; 2024 Wonder Weapons. Todos los derechos reservados.</p>
            <p><a href="#" class="text-white">Política de Privacidad</a> | <a href="#" class="text-white">Términos de
                    Servicio</a></p>
        </div>
    </footer>
    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

</body>

</html>