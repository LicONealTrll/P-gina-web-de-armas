<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
<!-- Estilo Carrito Css -->
    <link rel="stylesheet" href="../assets/css/carrito.css">
    <script src="../components/carrito.js"></script>
</head>
<body>

    <div class="container">
        <h1>Carrito de Compras</h1>
        
        <div class="section">
            <input type="text" id="search" placeholder="Buscar producto..." oninput="filterProducts()">
            <div id="product-list"></div>
        </div>
        
        <div class="section">
            <h2>Carrito</h2>
            <div id="cart"></div>
            <div id="total"></div>
            <button onclick="proceedToCheckout()">Proceder al Pago</button>
        </div>
    </div>

</body>
</html>
