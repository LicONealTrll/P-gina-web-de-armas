<?php
$servername = "localhost"; // Cambia esto si tu servidor es diferente
$username = "root"; // Cambia esto por tu usuario
$password = ""; // Cambia esto por tu contraseña
$dbname = "armas_db"; // Cambia esto por tu base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta para obtener los datos
$sql = "SELECT id_arma, modelo, tipo, calibre, fabricante, pais, fabricacion FROM armas"; // Ajusta esto según tu tabla
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de armas</title>
    <!--Estilo Boostrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Estilo de datatable -->
    <link rel="stylesheet" href="../assets/css/datatable.css">
    <!--Css Datatables-->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <!--JQuery-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!--Datatables-->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <!--Boostrap-->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div class="container mt-5">
        <h2 class="text-center">Tabla de armas</h2>

        <table id="tabladearmas" class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Modelo</th>
                    <th>Tipo</th>
                    <th>Calibre</th>
                    <th>Fabricante</th>
                    <th>País</th>
                    <th>Fecha de Fabricación</th>
                    <th>Más opciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Mostrar datos en la tabla
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                    <td>" . $row["id_arma"] . "</td>
                    <td>" . $row["modelo"] . "</td>
                    <td>" . $row["tipo"] . "</td>
                    <td>" . $row["calibre"] . "</td>
                    <td>" . $row["fabricante"] . "</td>
                    <td>" . $row["pais"] . "</td>
                    <td>" . $row["fabricacion"] . "</td>
                    <td>
                        <a href='editar.php?id=" . $row["id_arma"] . "' class='btn btn-warning btn-sm'>Editar</a>
                        <a href='eliminar.php?id=" . $row["id_arma"] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este registro?\");'>Eliminar</a>
                    </td>
                  </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No se encontraron resultados</td></tr>";
                }
                ?>
            </tbody>

        </table>
    </div>

    <script>
        $(document).ready(function () {
            $('#tabladearmas').DataTable({
                "language": {
                    "search": "Buscar:",
                    "lengthMenu": "Mostrar _MENU_ registros por página",
                    "info": "Mostrando de _START_ a _END_ de _TOTAL_ registros",
                    "paginate": {
                        "next": "Siguiente",
                        "previous": "Anterior"
                    }
                }
            });
        });
    </script>

</body>

</html>

<?php
$conn->close();
?>