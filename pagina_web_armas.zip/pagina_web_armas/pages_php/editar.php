<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "armas_db";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener el ID del arma
$id = $_GET['id'];
$sql = "SELECT * FROM armas WHERE id_arma = $id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recibir los datos del formulario
    $modelo = $_POST['modelo'];
    $tipo = $_POST['tipo'];
    $calibre = $_POST['calibre'];
    $fabricante = $_POST['fabricante'];
    $pais = $_POST['pais'];
    $fabricacion = $_POST['fabricacion'];

    // Actualizar el registro en la base de datos
    $sql = "UPDATE armas SET modelo='$modelo', tipo='$tipo', calibre='$calibre', fabricante='$fabricante', pais='$pais', fabricacion='$fabricacion' WHERE id_arma=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: ../index.php"); // Cambia 'index.php' al nombre de tu archivo principal
        exit();
    } else {
        echo "Error actualizando el registro: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar Arma</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Estilo Css -->
    <link rel="stylesheet" href="../assets/css/editar.css">
</head>

<body>

    <div class="container">
        <h2 class="text-center">EDITAR ARMA</h2>
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="modelo">Modelo:</label>
                <input type="text" class="form-control" name="modelo" id="modelo"
                    value="<?php echo htmlspecialchars($row['modelo']); ?>" required>
            </div>
            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <input type="text" class="form-control" name="tipo" id="tipo"
                    value="<?php echo htmlspecialchars($row['tipo']); ?>" required>
            </div>
            <div class="form-group">
                <label for="calibre">Calibre:</label>
                <input type="text" class="form-control" name="calibre" id="calibre"
                    value="<?php echo htmlspecialchars($row['calibre']); ?>" required>
            </div>
            <div class="form-group">
                <label for="fabricante">Fabricante:</label>
                <input type="text" class="form-control" name="fabricante" id="fabricante"
                    value="<?php echo htmlspecialchars($row['fabricante']); ?>" required>
            </div>
            <div class="form-group">
                <label for="pais">País:</label>
                <input type="text" class="form-control" name="pais" id="pais"
                    value="<?php echo htmlspecialchars($row['pais']); ?>" required>
            </div>
            <div class="form-group">
                <label for="fabricacion">Fecha de Fabricación:</label>
                <input type="date" class="form-control" name="fabricacion" id="fabricacion"
                    value="<?php echo htmlspecialchars($row['fabricacion']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Actualizar</button>
            <a href="../index.php" class="btn btn-secondary btn-block mt-2">Cancelar</a>
        </form>
    </div>

</body>

</html>

<?php
$conn->close();
?>