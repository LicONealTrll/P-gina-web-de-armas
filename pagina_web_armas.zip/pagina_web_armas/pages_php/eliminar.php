<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "armas_db";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener el ID del arma
$id = $_GET['id'];

// Eliminar el registro de la base de datos
$sql = "DELETE FROM armas WHERE id_arma = $id";
if ($conn->query($sql) === TRUE) {
    header("Location: ../index.php"); // Cambia 'index.php' al nombre de tu archivo principal
    exit();
} else {
    echo "Error eliminando el registro: " . $conn->error;
}

$conn->close();
?>
